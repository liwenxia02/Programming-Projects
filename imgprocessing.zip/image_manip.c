#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "image_manip.h"
#include "ppm_io.h"



/* HELPER for grayscale: (GIVEN)
 * convert a RGB pixel to a single grayscale intensity;
 * uses NTSC standard conversion
 */
unsigned char pixel_to_gray (const Pixel *p) {
  return (unsigned char)( (0.3 * (double)p->r) +
                          (0.59 * (double)p->g) +
                          (0.11 * (double)p->b) );
}


//______binarize______ (TODO)
/* convert image to black and white only based on threshold value
 */
Image * binarize (const Image *im, int threshold) {


  unsigned char grey = 0;
  //create a new array to store binary values
  Image *binarized = malloc(sizeof(Image));
  binarized -> rows = im -> rows;
  binarized -> cols = im -> cols;
  Pixel *orig = im->data;
  Pixel *new = malloc(sizeof(Pixel)*binarized ->rows*binarized->cols);

  for (int r=0; r<im->rows; r++) {
    for (int c=0; c<im->cols; c++) {
      grey = pixel_to_gray(&orig[r*(im->cols)+c]);
      if (grey>= (int)threshold) {
          new[r*im->cols+c].r  = 255;
          new[r*im->cols+c].g  = 255;
          new[r*im->cols+c].b  = 255;
      }
      else {
        new[r*im->cols+c].r = 0;
        new[r*im->cols+c].g = 0;
        new[r*im->cols+c].b = 0;
      }
    }
  }
  binarized->data = new;
  return binarized;
}



//______crop______ (TODO)
/* takes an image and points defining a bounding box,
 * and crops that box out of the image, returning a newly
 * created image containing just the cropped region
 */
Image *crop (const Image *im, int topCol, int topRow,int bottomCol, int bottomRow) {

  Image *cropped = malloc(sizeof(Image));
  cropped->rows = bottomRow-topRow;
  cropped->cols = bottomCol-topCol;
  Pixel *orig = im->data;
  Pixel *new = malloc(sizeof(Pixel)*cropped->rows *cropped->cols);
  int i=0;

  //copy cropped region pixels into new array
  for(int r = topRow; r < bottomRow; r++){
    for(int c = topCol; c < bottomCol; c++){
      new[i] = orig[r*im->cols+c]; 
      ++i;
    }
  }
  cropped->data = new;
  return cropped;
      
}



//______blur______ (TODO)
/* apply a blurring filter to the image
 */

Image *blur(Image *img, double s){
  int n = (int)(ceil(10*s)); //parameter N must be at least 10*s large and must be odd
  n = (n%2 == 0) ? n+1 : n; // makes n odd
  double filter[n][n];
  Image *blurred = make_copy(img);
  for(int r = 0; r < n; r++){
    for(int c = 0; c < n; c++){
      //filling the matrix with Gaussian filter values
      filter[r][c]= (1.0 / (2.0 * PI * sq(s))) * exp( -(sq(n/2-r) + sq(n/2-c)) / (2 * sq(s)));
    }
  }
  for(int r = 0; r < (img->rows); r++){
    for(int c = 0; c < (img->cols); c++){
      // the filter matrix is centered around the current Pixel: (im->data)[r*(im->cols)+c];
      double weightedr[n][n];
      double weightedg[n][n];
      double weightedb[n][n];
      // now, fill the weighted image by multiplying the filter values with Pixel values
      for(int x = -n/2; x <= n/2; x++){
	for(int y = -n/2; y <= n/2; y++){
	  int rfromcenter = r + x; //basically dx from row = r
	  int cfromcenter = c + y; //basically dy from col = c
	  //rfromcenter and cfromcenter are the indices of the filter array applied onto the Pixel array
	  if (rfromcenter<0 || cfromcenter<0 || rfromcenter>(img->rows)-1 || cfromcenter>(img->cols)-1){ //if the current filter element is outside of the Pixel array
	    //x+n/2 and y+n/2 are the indices of the filter array (i.e. from 0 to n in both rows and cols)
	    weightedr[x + n/2][y+n/2]= -1.0;
	    weightedg[x + n/2][y+n/2]= -1.0;
	    weightedb[x + n/2][y+n/2]= -1.0; //negative value tells us to ignore calculation at this element
          }
	  else { //multiply the sigma value by the r, g, b values
	    weightedr[x + n/2][y+n/2]= ((img->data)[rfromcenter * (img->cols) + cfromcenter]).r	* filter[x+n/2][y+n/2];
	    weightedg[x + n/2][y+n/2]= ((img->data)[rfromcenter * (img->cols) + cfromcenter]).g	* filter[x+n/2][y+n/2];
	    weightedb[x + n/2][y+n/2]= ((img->data)[rfromcenter * (img->cols) + cfromcenter]).b	* filter[x+n/2][y+n/2];
	  }
	}
      }
      //now we can calculate our weighted sums
      double rsum = 0;
      double gsum = 0;
      double bsum = 0;
      double filtersum = 0;
      for(int a = 0; a < n; a++){
	for(int b = 0; b < n; b++){
	  if (weightedr[a][b]<0){
	    //ignore this element
	  }
	  else{
	    rsum += weightedr[a][b]; //sums up the weighted Pixel values
	    gsum += weightedg[a][b];
	    bsum += weightedb[a][b];
	    filtersum += filter[a][b]; //sums up the Gaussian values
	  }
	}
      }
      ((blurred->data)[r*(img->cols)+c]).r = (int)(rsum/filtersum); //blurs the image by normalizing the weighted sums
      ((blurred->data)[r*(img->cols)+c]).g = (int)(gsum/filtersum);
      ((blurred->data)[r*(img->cols)+c]).b = (int)(bsum/filtersum);
    }	    
  }
  return blurred;
}

//______zoom_in______ (TODO)
/* "zoom in" an image, by duplicating each pixel into a 2x2 square of pixels
 */

Image *zoom_in(Image *img){
  Image *zoomed = malloc(sizeof(Image));
  zoomed->rows = 2*(img->rows); //setting new rows and cols to twice the original value
  zoomed->cols = 2*(img->cols);
  Pixel *original = img->data;
  Pixel *mydata = malloc(sizeof(Pixel)*zoomed->rows*zoomed->cols); //allocates room for new array of Pixels
  for(int r = 0; r < img->rows; r++){
    for(int c = 0; c < img->cols; c++){
      int newr = 2*r; 
      int newc = 2*c;
      mydata[newr*zoomed->cols+newc] = original[r*img->cols+c]; //1 Pixel from the original into 4 new Pixels 
      mydata[(newr+1)*zoomed->cols+newc] = original[r*img->cols+c]; //rows and columns go from 2n to 2n+1
      mydata[newr*zoomed->cols+newc+1] = original[r*img->cols+c];
      mydata[(newr+1)*zoomed->cols+newc+1] = original[r*img->cols+c];
    }}
  zoomed->data = mydata; //sets the Pixel array of zoomed equal to the array we just made
 return zoomed;}

// _______rotate-left________ (TODO)
/* rotate the input image counter-clockwise 90 degrees
 */
Image *rotate_left(Image *im) {
  Image *rotated = malloc(sizeof(Image));
  rotated->rows = im->cols;
  rotated->cols = im->rows;
  Pixel *orig = im->data;
  Pixel *new = malloc(sizeof(Pixel)*rotated->rows*rotated->cols);

  for (int r=0; r<im->rows; r++) {
    for (int c=0; c<im->cols; c++) {
      new[(im->cols-c-1)*rotated->cols+r] = orig[r*im->cols+c]; 
    }
  }
  rotated->data = new;
  return rotated;
}


// _______pointilism________ (TODO)
/* apply a painting like effect i.e. pointilism technique.
 */
Image *pointilism(Image *im){
  Image *result = make_copy(im);
  for(int i = 0; i < (int)((im->rows)*(im->cols)*0.03); i++){ //conducts operation on 3% of the total Pixels
    //order of randoms: column, row, radius
    //btw rand()%100 gives value from 0 to 99
    int curcol = rand()%(im->cols);//generates random value between 0 and img->cols-1
    int	currow = rand()%(im->rows);//generates random value between 0 and img->rows-1    
    int radius = rand()%5+1; //generates random value between 1 and 5 for the radius
    //try to reduce the iterations through image since we use nested loops
    //search through a square of sidelength 2*radius + 1 instead of the whole image
    int startr = currow-radius >= 0 ? currow - radius : 0;
    int endr = currow+radius < im->rows ? currow + radius : (im->rows)-1;
    int	startc = curcol-radius >= 0 ? curcol - radius : 0;
    int	endc = curcol+radius < im->cols	? curcol + radius : (im->cols)-1;
    for(int r = startr; r <= endr; r++){
      for(int c = startc; c <= endc; c++){ //checks the distance of each Pixel to our current Pixel
        //distance formula is sqrt((x2-x1)^2+(y2-y1)^2)  
	double distance = sqrt(pow((double)(r-currow),2.0)+pow((double)(c-curcol),2.0));
	  if(distance <= (double)radius){ //applies pointilism if Pixel is within the radius to the center Pixel
	    (result->data)[r*(result->cols)+c] = (im->data)[currow*(im->cols)+curcol];
	  }
      }
    }
  }
  return result;
}
