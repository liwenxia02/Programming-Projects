//project.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ppm_io.h"
#include "image_manip.h"

// Return (exit) codes
#define RC_SUCCESS            0
#define RC_MISSING_FILENAME   1
#define RC_OPEN_FAILED        2
#define RC_INVALID_PPM        3
#define RC_INVALID_OPERATION  4
#define RC_INVALID_OP_ARGS    5
#define RC_OP_ARGS_RANGE_ERR  6
#define RC_WRITE_FAILED       7
#define RC_UNSPECIFIED_ERR    8

void print_usage();

int main (int argc, char* argv[]) {

  // less than 2 command line args means that input or output filename
  // wasn't specified
  if (argc < 3) {
    fprintf(stderr, "Missing input/output filenames\n");
    print_usage();
    return RC_MISSING_FILENAME;
  }

  // TODO: implement the rest of this project!

  //get input filename
  char *inFile = argv[1];
	    
  
  //read file
  FILE *in = fopen(inFile, "rb");
  if (!in) {
    printf("Couldn't open input file: %s\n", inFile);
    return RC_OPEN_FAILED;
  }
  Image *im = read_ppm(in);

  fclose(in);

  //implement functions
  if (!strcmp(argv[3], "binarize")) {
    printf("binarize called");
    //if (argv[3]=="binarize") {//implement binarize
    if ((atoi(argv[4])<0) || (atoi(argv[4])>255)) { //check threshold is between 0 and 255
      printf("Error: invalid threshold\n");
      return RC_OP_ARGS_RANGE_ERR;
    }
    if (argc != 5) {
      printf("Error");
      return RC_INVALID_OP_ARGS;
    }
    im = binarize(im, atoi(argv[4]));
  }

  else if (!strcmp(argv[3], "crop")) {//implement crop
    if (argc != 8) { //check 4 additional arguments
      printf("Error: invalid number of arguments\n");
      return RC_INVALID_OP_ARGS;
    }
    if ((atoi(argv[5])<0) || (atoi(argv[7])>im->rows) || (atoi(argv[4])<0) || (atoi(argv[6])>im->cols) || (atoi(argv[4])>atoi(argv[6])) || (atoi(argv[5])>atoi(argv[7]))) {//check that corners make sense
      printf("Error: invalid arguments\n");
      return RC_OP_ARGS_RANGE_ERR;
  }
    im = crop(im, atoi(argv[4]),atoi(argv[5]), atoi(argv[6]), atoi(argv[7]));
  }

  
  else if (!strcmp(argv[3], "rotate_left")) {//implement rotate left
    if (argc != 4) {//check correct number of inputs
      printf("Error: invalid number of arguments\n");
      return RC_INVALID_OP_ARGS;
    }      
    im = rotate_left(im);
    
  }
  else if (!strcmp(argv[3], "zoom_in")) {//implement zoom in
    if (argc != 4) { //check correct number pf inputs
      printf("Error: invalid number of arguments\n");
      return RC_INVALID_OP_ARGS;
    }

    im = zoom_in(im);
  }
  else if (!strcmp(argv[3], "pointilism")) {
    if (argc != 4) { //check correct number of inputs
      printf("Error: invalid number of arguments\n");
      return RC_INVALID_OP_ARGS;
    }
    im = pointilism(im);
  }
  else if (!strcmp(argv[3], "blur")) {
    if (argc != 5) {//check correct number of inputs    
      printf("Error: invalid number of arguments\n");
      return RC_INVALID_OP_ARGS;
    }
    im = blur(im, atof(argv[4]));
    
		
  }

  
  else {//if argv[3] is not a supported function
    printf("Unsupported image processing operations\n");
    return RC_INVALID_OPERATION;
  }

  //write output image to file
  char *outFile = argv[2];
  
  FILE *out = fopen(outFile, "wb");
  if (out==NULL) {
    printf("Couldn't open output file: %s\n", outFile);
    return RC_OPEN_FAILED;
  }
  if (ferror(out)) {
    printf("Error: error in output file\n");
    return RC_WRITE_FAILED;
  }
    
  int num_pixels_written = write_ppm(out, im);
  printf("Image created with %d pixels\n", num_pixels_written);
  fclose(out);      
      
  
  return RC_SUCCESS;
}

void print_usage() {
  printf("USAGE: ./project <input-image> <output-image> <command-name> <command-args>\n");
  printf("SUPPORTED COMMANDS:\n");
  printf("   binarize <treshhold>\n");
  printf("   crop <top-lt-col> <top-lt-row> <bot-rt-col> <bot-rt-row>\n");
  printf("   zoom_in\n");
  printf("   rotate-left\n");
  printf("   pointilism\n");
  printf("   blur <sigma>\n");
}


